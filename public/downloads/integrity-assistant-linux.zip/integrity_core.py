import cv2
import numpy as np
import pyautogui
import time
import os
from PIL import Image
import json
import hashlib
from datetime import datetime, timedelta
import threading
import sqlite3
import shutil
import easyocr
from typing import List, Dict, Optional, Tuple, Set
import logging
import requests

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("integrity.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("integrity")

class HashStorage:
    """Efficient storage using screen content hashing to avoid duplicate captures."""
    
    def __init__(self):
        self.last_hash = None
        self.unchanged_count = 0
        self.last_changed_time = time.time()
    
    def is_different(self, image, threshold=0.95) -> Tuple[bool, str]:
        """
        Check if the current screen is significantly different from the previous one.
        
        Args:
            image: PIL Image object of the current screen
            threshold: Similarity threshold below which images are considered different
            
        Returns:
            Tuple of (is_different, image_hash)
        """
        # Convert to grayscale and resize to reduce computation
        img_np = np.array(image)
        img_gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
        img_resized = cv2.resize(img_gray, (32, 32))
        
        # Compute perceptual hash
        img_hash = hashlib.md5(img_resized.tobytes()).hexdigest()
        
        if self.last_hash is None:
            self.last_hash = img_hash
            return True, img_hash
        
        # Calculate similarity using pixel-wise comparison of the resized image
        if img_hash == self.last_hash:
            self.unchanged_count += 1
            # If screen hasn't changed in a long time, still capture occasionally
            if self.unchanged_count >= 60 and (time.time() - self.last_changed_time) > 300:  # 5 minutes
                self.unchanged_count = 0
                self.last_changed_time = time.time()
                return True, img_hash
            return False, img_hash
        else:
            self.last_hash = img_hash
            self.unchanged_count = 0
            self.last_changed_time = time.time()
            return True, img_hash

class ScreenCapture:
    def __init__(self, storage_dir="integrity_data", sampling_rate=0.5, server_url=None, user_id=None, user_token=None):
        """
        Initialize the screen capture system with cloud synchronization.
        
        Args:
            storage_dir: Directory for storing temporary data
            sampling_rate: Capture frequency in Hz (captures per second)
            server_url: URL of the Integrity server
            user_id: User ID for API calls
            user_token: JWT token for authentication
        """
        self.storage_dir = storage_dir
        self.img_dir = os.path.join(storage_dir, "images")
        self.sampling_rate = sampling_rate
        self.server_url = server_url
        self.user_id = user_id
        self.user_token = user_token
        
        # Create directories
        os.makedirs(self.img_dir, exist_ok=True)
        
        # Initialize SQLite database (for local caching only)
        self.db_path = os.path.join(storage_dir, "integrity_cache.db")
        self.init_database()
        
        # Initialize EasyOCR
        logger.info("Initializing EasyOCR (this may take a moment)...")
        self.reader = easyocr.Reader(['en'])
        logger.info("EasyOCR initialized successfully!")
        
        # Initialize hash-based storage
        self.hash_storage = HashStorage()
        
        # Threading resources
        self.is_running = False
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        
        # Runtime statistics
        self.stats = {
            "total_captures": 0,
            "unique_captures": 0,
            "ocr_errors": 0,
            "server_errors": 0,
            "start_time": None,
            "last_capture_time": None
        }
    
    def init_database(self):
        """Initialize SQLite database for local caching."""
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            
            # Local cache table
            c.execute('''
                CREATE TABLE IF NOT EXISTS activity_cache (
                    timestamp TEXT PRIMARY KEY,
                    extracted_text TEXT,
                    app_context TEXT,
                    image_hash TEXT,
                    synced BOOLEAN DEFAULT 0
                )
            ''')
            
            # Create indexes
            c.execute('CREATE INDEX IF NOT EXISTS idx_cache_synced ON activity_cache(synced)')
            
            conn.commit()
    
    def get_active_window_title(self) -> Optional[Tuple[str, str]]:
        """
        Get the active window title and application name.
        Platform-specific implementation.
        
        Returns:
            Tuple of (application_name, window_title) or None if not available
        """
        try:
            import platform
            system = platform.system()
            
            if system == "Windows":
                # Windows implementation
                import win32gui
                window = win32gui.GetForegroundWindow()
                app_name = win32gui.GetWindowText(window)
                # Split by common delimiters
                if " - " in app_name:
                    parts = app_name.split(" - ")
                    return parts[-1], app_name
                return app_name, app_name
                
            elif system == "Darwin":  # macOS
                # macOS implementation using applescript
                import subprocess
                script = 'tell application "System Events" to get name of first application process whose frontmost is true'
                app_name = subprocess.check_output(['osascript', '-e', script]).decode().strip()
                
                script = 'tell application "System Events" to get name of front window of first application process whose frontmost is true'
                try:
                    window_title = subprocess.check_output(['osascript', '-e', script]).decode().strip()
                except:
                    window_title = app_name
                
                return app_name, window_title
                
            elif system == "Linux":
                # Linux implementation using xdotool
                try:
                    import subprocess
                    window_id = subprocess.check_output(['xdotool', 'getactivewindow']).decode().strip()
                    window_title = subprocess.check_output(['xdotool', 'getwindowname', window_id]).decode().strip()
                    window_class = subprocess.check_output(['xdotool', 'getwindowclassname', window_id]).decode().strip()
                    return window_class, window_title
                except:
                    return None
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting window title: {e}")
            return None
    
    def capture_screen(self):
        """
        Capture the screen and process if it's different from previous captures.
        """
        try:
            # Take screenshot
            image = pyautogui.screenshot()
            
            # Check if the screen has changed significantly
            is_different, img_hash = self.hash_storage.is_different(image)
            
            if not is_different:
                self.stats["total_captures"] += 1
                return None, None, None, img_hash
            
            # Generate timestamp and save image
            timestamp = datetime.now().isoformat()
            
            # Get active window title for context
            app_title = self.get_active_window_title()
            
            # Process the image to extract text
            extracted_text = self.process_image(image)
            
            # Prepare app context
            app_context = {}
            if app_title:
                app_name, window_title = app_title
                app_context = {
                    "application": app_name,
                    "window_title": window_title
                }
            
            # Cache the data locally
            with self.lock:
                with sqlite3.connect(self.db_path) as conn:
                    c = conn.cursor()
                    c.execute(
                        "INSERT INTO activity_cache VALUES (?, ?, ?, ?, ?)",
                        (timestamp, extracted_text, json.dumps(app_context), img_hash, 0)
                    )
                    conn.commit()
            
            # Send to server (if connected) - only send text data, not screenshots
            if self.server_url and self.user_id and self.user_token:
                self.send_to_server(timestamp, extracted_text, app_context)
            
            # Update statistics
            self.stats["total_captures"] += 1
            self.stats["unique_captures"] += 1
            self.stats["last_capture_time"] = timestamp
            
            return timestamp, extracted_text, app_context, img_hash
            
        except Exception as e:
            logger.error(f"Error capturing screen: {e}")
            return None, None, None, None
    
    def process_image(self, image):
        """
        Extract text from the captured image using EasyOCR.
        """
        try:
            # Convert PIL Image to numpy array
            image_np = np.array(image)
            
            # Use EasyOCR to detect text
            results = self.reader.readtext(image_np)
            
            # Extract text while maintaining position order (top to bottom, left to right)
            sorted_results = sorted(results, key=lambda x: (x[0][0][1], x[0][0][0]))
            
            # Join the text parts while maintaining order
            extracted_text = '\n'.join([result[1] for result in sorted_results])
            
            return extracted_text
            
        except Exception as e:
            logger.error(f"Error processing image: {e}")
            self.stats["ocr_errors"] += 1
            return ""
    
    def send_to_server(self, timestamp, extracted_text, app_context):
        """
        Send captured data to the server.
        """
        try:
            # Send extracted text and context
            response = requests.post(
                f"{self.server_url}/api/store-activity",
                json={
                    "user_id": self.user_id,
                    "extracted_text": extracted_text,
                    "timestamp": timestamp,
                    "app_context": app_context
                },
                headers={"Authorization": f"Bearer {self.user_token}"}
            )
            
            if response.status_code == 200:
                # Mark as synced in local cache
                with self.lock:
                    with sqlite3.connect(self.db_path) as conn:
                        c = conn.cursor()
                        c.execute(
                            "UPDATE activity_cache SET synced = 1 WHERE timestamp = ?",
                            (timestamp,)
                        )
                        conn.commit()
            else:
                logger.error(f"Server error while sending activity: {response.status_code}, {response.text}")
                self.stats["server_errors"] += 1
                
        except Exception as e:
            logger.error(f"Error sending to server: {e}")
            self.stats["server_errors"] += 1
    
    def sync_pending_activities(self):
        """
        Sync any pending activities to the server.
        """
        if not self.server_url or not self.user_id or not self.user_token:
            return
            
        try:
            with self.lock:
                with sqlite3.connect(self.db_path) as conn:
                    conn.row_factory = sqlite3.Row
                    c = conn.cursor()
                    c.execute("SELECT * FROM activity_cache WHERE synced = 0")
                    pending = c.fetchall()
            
            for row in pending:
                # Send to server
                response = requests.post(
                    f"{self.server_url}/api/store-activity",
                    json={
                        "user_id": self.user_id,
                        "extracted_text": row['extracted_text'],
                        "timestamp": row['timestamp'],
                        "app_context": json.loads(row['app_context'])
                    },
                    headers={"Authorization": f"Bearer {self.user_token}"}
                )
                
                if response.status_code == 200:
                    # Mark as synced
                    with self.lock:
                        with sqlite3.connect(self.db_path) as conn:
                            c = conn.cursor()
                            c.execute(
                                "UPDATE activity_cache SET synced = 1 WHERE timestamp = ?",
                                (row['timestamp'],)
                            )
                            conn.commit()
                else:
                    logger.error(f"Server error during sync: {response.status_code}, {response.text}")
                    self.stats["server_errors"] += 1
                    
                # Avoid overloading the server
                time.sleep(0.5)
                
        except Exception as e:
            logger.error(f"Error syncing pending activities: {e}")
            self.stats["server_errors"] += 1
    
    def capture_loop(self):
        """
        Main capture loop with adaptive sampling rate and power management.
        """
        self.stats["start_time"] = datetime.now().isoformat()
        
        while not self.stop_event.is_set():
            loop_start = time.time()
            
            # Adaptive capture based on system state
            # If screen hasn't changed in a long time, reduce sampling rate
            current_rate = self.sampling_rate
            if self.hash_storage.unchanged_count > 300:  # 5 minutes of no change
                current_rate = self.sampling_rate / 4
            
            # Capture screen and process if different
            self.capture_screen()
            
            # Sync pending activities periodically
            if time.time() % 60 < 2:  # Every minute approximately
                threading.Thread(target=self.sync_pending_activities, daemon=True).start()
            
            # Sleep for the remainder of the frame time
            elapsed = time.time() - loop_start
            sleep_time = max(0, (1.0 / current_rate) - elapsed)
            
            if sleep_time > 0:
                time.sleep(sleep_time)
    
    def start_capture(self):
        """Start the screen capture process in a separate thread."""
        self.is_running = True
        self.stop_event.clear()
        self.capture_thread = threading.Thread(target=self.capture_loop, daemon=True)
        self.capture_thread.start()
        logger.info("Screen capture started...")
    
    def stop_capture(self):
        """Stop the capture process gracefully."""
        self.stop_event.set()
        if hasattr(self, 'capture_thread'):
            self.capture_thread.join(timeout=2.0)
        self.is_running = False
        logger.info("Screen capture stopped.")
        
        # Final sync of pending activities
        self.sync_pending_activities()
    
    def get_statistics(self):
        """Return capture statistics."""
        return {
            **self.stats,
            "runtime": (datetime.now() - datetime.fromisoformat(self.stats["start_time"])).total_seconds() if self.stats["start_time"] else 0,
            "efficiency": f"{(self.stats['unique_captures'] / max(1, self.stats['total_captures']) * 100):.2f}%",
            "server_connection": "Connected" if self.server_url and self.stats["server_errors"] == 0 else 
                                "Connection issues" if self.stats["server_errors"] > 0 else "Offline"
        }
    
    def export_text_to_file(self, output_file="extracted_text.txt", days=1):
        """
        Export extracted text from the last N days to a text file in chronological order.
        """
        cutoff_date = datetime.now() - timedelta(days=days)
        cutoff_timestamp = cutoff_date.isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            c.execute("""
                SELECT timestamp, extracted_text, app_context
                FROM activity_cache
                WHERE timestamp > ?
                ORDER BY timestamp ASC
            """, (cutoff_timestamp,))
            results = c.fetchall()
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for row in results:
                if row['extracted_text'] and row['extracted_text'].strip():  # Only write non-empty text
                    dt = datetime.fromisoformat(row['timestamp'])
                    formatted_time = dt.strftime('%Y-%m-%d %H:%M:%S')
                    
                    context_str = ""
                    if row['app_context']:
                        app_context = json.loads(row['app_context'])
                        app_name = app_context.get('application')
                        window_title = app_context.get('window_title')
                        if app_name and window_title:
                            context_str = f" [{app_name} - {window_title}]"
                        elif app_name:
                            context_str = f" [{app_name}]"
                    
                    f.write(f"[{formatted_time}]{context_str}\n{row['extracted_text']}\n\n")
        
        return output_file