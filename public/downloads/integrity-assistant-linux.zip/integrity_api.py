import os
import json
import time
import requests
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Any, Optional, Tuple

logger = logging.getLogger("integrity.api")

class IntegrityAPI:
    """
    API client for Integrity Assistant, handling communication with the server.
    """
    def __init__(self, server_url: str, user_id: str = None, user_token: str = None):
        """
        Initialize the API client.
        
        Args:
            server_url: URL of the Integrity server
            user_id: User ID for API calls
            user_token: JWT token for authentication
        """
        self.server_url = server_url
        self.user_id = user_id
        self.user_token = user_token
        
    def register_user(self, email: str, username: str) -> Tuple[bool, str, Optional[str]]:
        """
        Register a new user with the Integrity server.
        
        Args:
            email: User's email address
            username: User's chosen username
            
        Returns:
            Tuple of (success, message, token)
        """
        try:
            response = requests.post(
                f"{self.server_url}/api/register",
                json={
                    "email": email,
                    "username": username
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                self.user_id = data.get("user_id")
                self.user_token = data.get("token")
                return True, "Registration successful", self.user_token
            else:
                error_msg = response.json().get("error", "Unknown error")
                return False, f"Registration failed: {error_msg}", None
                
        except Exception as e:
            logger.error(f"Error during registration: {e}")
            return False, f"Connection error: {str(e)}", None
    
    def check_connection(self) -> bool:
        """Check if the server is reachable."""
        try:
            response = requests.get(f"{self.server_url}/api/health", timeout=10)
            if response.status_code == 200:
                logger.info(f"Successfully connected to server at {self.server_url}")
                return True
            else:
                logger.error(f"Server connection failed with status code {response.status_code}")
                return False
        except Exception as e:
            logger.error(f"Server connection error: {str(e)}")
            return False
    
    def get_daily_limit(self) -> Dict[str, int]:
        """Get the remaining daily question limit."""
        try:
            response = requests.get(
                f"{self.server_url}/api/daily-limit",
                params={"user_id": self.user_id},
                headers={"Authorization": f"Bearer {self.user_token}"}
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {"total_limit": 100, "used": 0, "remaining": 100}
                
        except Exception as e:
            logger.error(f"Error getting daily limit: {e}")
            return {"total_limit": 100, "used": 0, "remaining": 100}
    
    def query_model(self, question: str, text_content: str = None) -> str:
        """
        Send a query to the server for processing.
        
        Args:
            question: User's question
            text_content: Optional text content (not used, kept for compatibility)
            
        Returns:
            Model's response as a string
        """
        try:
            # Check connection first
            if not self.check_connection():
                logger.error("Failed to connect to server")
                return "I'm currently unable to connect to the Integrity server. Please check your internet connection and try again."
            
            logger.info(f"Sending query to server: {question[:50]}...")
            
            # Send query to server
            response = requests.post(
                f"{self.server_url}/api/query",
                json={
                    "user_id": self.user_id,
                    "question": question
                },
                headers={"Authorization": f"Bearer {self.user_token}"},
                timeout=30  # Increased timeout for model responses
            )
            
            logger.info(f"Received response with status code: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                return data.get("answer", "Sorry, I couldn't process your request.")
            elif response.status_code == 429:
                data = response.json()
                return data.get("message", "You've reached your daily limit of 100 questions. Please try again tomorrow.")
            else:
                error_msg = response.json().get("error", "Unknown error")
                logger.error(f"Server returned error: {error_msg}")
                return f"Sorry, I encountered an error: {error_msg}"
                
        except Exception as e:
            logger.error(f"Error querying model: {e}")
            return f"Sorry, I encountered an error while processing your request: {str(e)}"