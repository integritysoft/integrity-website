#!/bin/bash
# Integrity Assistant Installer

echo "==========================================="
echo "    Integrity Assistant v0.1.2 Alpha"
echo "==========================================="
echo

# Check for Python
python3 --version >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "Python 3 not found. Please install Python 3.8 or newer."
    exit 1
fi

# Check Python version
py_version=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
if (( $(echo "$py_version < 3.8" | bc -l) )); then
    echo "Error: Python 3.8 or newer is required. Found version $py_version"
    exit 1
fi

echo "Found Python $py_version"

# Create installation directory
INSTALL_DIR="$HOME/IntegrityAssistant"
echo "Creating installation directory $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"

# Copy program files
echo "Copying program files..."
cp -f ./*.py "$INSTALL_DIR/"
if [ $? -ne 0 ]; then
    echo "Error: Failed to copy program files."
    exit 1
fi

# Create virtual environment in installation directory
echo "Creating virtual environment..."
cd "$INSTALL_DIR"
python3 -m venv venv
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install --upgrade pip
pip install customtkinter==5.2.0 easyocr==1.7.0 opencv-python==4.8.0.76 numpy==1.24.3 pillow==10.0.0 requests==2.28.2 PyJWT==2.6.0

# Create config directory
echo "Creating configuration directory..."
mkdir -p ~/.integrity/data/images

# Create desktop launcher for Linux systems
if [ "$(uname)" == "Linux" ]; then
    echo "Creating desktop launcher..."
    cat > "$HOME/.local/share/applications/integrity-assistant.desktop" << EOF
[Desktop Entry]
Name=Integrity Assistant
Comment=AI-powered digital assistant
Exec=bash -c "cd $INSTALL_DIR && source venv/bin/activate && python3 integrity_main.py"
Terminal=false
Type=Application
Icon=$INSTALL_DIR/icon.png
Categories=Utility;
EOF
    echo "Desktop launcher created. You can find Integrity Assistant in your applications menu."
fi

# Create startup script
echo "Creating startup script..."
cat > "$INSTALL_DIR/start_integrity.sh" << EOF
#!/bin/bash
cd "$INSTALL_DIR"
source venv/bin/activate
python3 integrity_main.py
EOF
chmod +x "$INSTALL_DIR/start_integrity.sh"

# Create a symlink to the script in a bin directory if it exists
if [ -d "$HOME/bin" ]; then
    ln -sf "$INSTALL_DIR/start_integrity.sh" "$HOME/bin/integrity-assistant"
    echo "Created symlink in $HOME/bin. You can start Integrity Assistant by typing 'integrity-assistant'."
fi

# Setup complete
echo
echo "==========================================="
echo "Integrity Assistant is ready to launch!"
echo
echo "Starting Integrity Assistant..."
echo "==========================================="

# Launch the application
./start_integrity.sh