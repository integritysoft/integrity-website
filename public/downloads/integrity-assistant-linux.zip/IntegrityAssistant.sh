#!/bin/bash

echo "==================================================="
echo "        Integrity Assistant v0.1.2 Alpha"
echo "==================================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed or not in your PATH."
    echo "Please install Python 3.8 or newer from python.org or your package manager."
    read -p "Press Enter to exit..."
    exit 1
fi

# Get the directory of this script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "First-time setup: Creating virtual environment..."
    python3 -m venv venv
    source venv/bin/activate
    echo "Installing dependencies..."
    pip install -r requirements.txt
    echo "Setup complete!"
else
    source venv/bin/activate
fi

# Run the application
python3 integrity_main.py

# Deactivate virtual environment at exit
deactivate

read -p "Press Enter to exit..." 