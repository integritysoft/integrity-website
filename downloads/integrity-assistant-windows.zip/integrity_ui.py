import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import customtkinter as ctk
from PIL import Image, ImageTk
import threading
import time
import math
import os
import logging
from datetime import datetime, timedelta
import json
from typing import Dict, List, Any, Optional, Callable

logger = logging.getLogger("integrity.ui")

# Define color scheme - enhanced light bluish turquoise on darker black
COLOR_SCHEME = {
    "bg_dark": "#0F1419",       # Deeper background 
    "bg_medium": "#161B22",     # Richer medium background
    "primary": "#0DFFD7",       # Brighter turquoise
    "primary_hover": "#00D6B5", # Deeper hover state
    "secondary": "#64FFDA",     # Secondary light turquoise
    "text_primary": "#FFFFFF",  # Primary text color
    "text_secondary": "#A7A7A7",# Secondary text color
    "accent": "#01ECE4",        # Accent color
    "error": "#FF5252",         # Error color
    "success": "#00E676",       # Success color
    "border": "#2A3140",        # Subtle border color
}

# Configure CustomTkinter appearance
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class PulsatingIcon(ctk.CTkCanvas):
    """Animated pulsating icon for the UI."""
    
    def __init__(self, parent, size=30, **kwargs):
        super().__init__(parent, width=size, height=size, bg=COLOR_SCHEME["bg_dark"], 
                       highlightthickness=0, **kwargs)
        self.size = size
        self.pulse_size = size
        self.min_size = size * 0.8
        self.max_size = size * 1.2
        self.pulse_growing = True
        self.pulse_speed = 0.05
        self.running = False
        self.color = COLOR_SCHEME["primary"]
        
    def start(self):
        """Start the pulsating animation."""
        self.running = True
        self.update_pulse()
        
    def stop(self):
        """Stop the pulsating animation."""
        self.running = False
        
    def update_pulse(self):
        """Update the pulsating effect."""
        if not self.running:
            return
            
        self.delete("pulse")
        
        # Calculate pulse size
        if self.pulse_growing:
            self.pulse_size += self.pulse_speed
            if self.pulse_size >= self.max_size:
                self.pulse_growing = False
        else:
            self.pulse_size -= self.pulse_speed
            if self.pulse_size <= self.min_size:
                self.pulse_growing = True
                
        # Draw the pulse circle
        x, y = self.size / 2, self.size / 2
        radius = self.pulse_size / 2
        
        self.create_oval(
            x - radius, 
            y - radius, 
            x + radius, 
            y + radius, 
            fill=self.color, 
            outline="", 
            tags="pulse"
        )
        
        self.after(20, self.update_pulse)


class ModernSpinner(ctk.CTkCanvas):
    """Modern loading spinner with smooth animation."""
    
    def __init__(self, parent, size=40, width=3, **kwargs):
        super().__init__(parent, width=size, height=size, bg=COLOR_SCHEME["bg_dark"], 
                       highlightthickness=0, **kwargs)
        self.size = size
        self.width = width
        self.angle = 0
        self.running = False
        self.segments = 12
        self.color = COLOR_SCHEME["primary"]
        
    def start(self):
        """Start the spinner animation."""
        self.running = True
        self.update_spinner()
        
    def stop(self):
        """Stop the spinner animation."""
        self.running = False
        self.delete("spinner")
        
    def update_spinner(self):
        """Update the spinner animation frame."""
        if not self.running:
            return
            
        self.delete("spinner")
        
        # Create multiple segments with varying opacity
        for i in range(self.segments):
            angle = (self.angle + (360 / self.segments) * i) % 360
            opacity = 1 - (i / self.segments)
            color_hex = self.calculate_color(opacity)
            
            start_angle = angle
            extent = 360 / self.segments - 2
            
            self.create_arc(
                self.width/2, 
                self.width/2, 
                self.size-self.width/2, 
                self.size-self.width/2,
                start=start_angle, 
                extent=extent, 
                width=self.width, 
                outline=color_hex, 
                tags="spinner",
                style=tk.ARC
            )
        
        self.angle = (self.angle + 10) % 360
        self.after(20, self.update_spinner)
        
    def calculate_color(self, opacity):
        """Calculate color with opacity for smooth gradient effect."""
        r, g, b = int(self.color[1:3], 16), int(self.color[3:5], 16), int(self.color[5:7], 16)
        opacity_int = int(opacity * 255)
        return f"#{r:02x}{g:02x}{b:02x}"


class GlowButton(ctk.CTkButton):
    """Custom button with glow effect on hover."""
    
    def __init__(self, *args, **kwargs):
        self.hover_color = kwargs.pop("hover_color", COLOR_SCHEME["primary_hover"])
        super().__init__(*args, **kwargs)
        
        # Override default styling
        self.configure(
            corner_radius=12,
            border_width=1,
            border_color=COLOR_SCHEME["primary"],
            fg_color=COLOR_SCHEME["bg_medium"],
            hover_color=self.hover_color,
            text_color=COLOR_SCHEME["primary"],
            font=("Segoe UI", 12),
            height=38
        )
        
        # Add hover and leave bindings for glow effect
        self.bind("<Enter>", self._on_hover)
        self.bind("<Leave>", self._on_leave)
        
    def _on_hover(self, event=None):
        """Handle mouse enter event for hover effect."""
        self.configure(
            fg_color=self.hover_color,
            text_color=COLOR_SCHEME["bg_dark"]
        )
        
    def _on_leave(self, event=None):
        """Handle mouse leave event for hover effect."""
        self.configure(
            fg_color=COLOR_SCHEME["bg_medium"],
            text_color=COLOR_SCHEME["primary"]
        )


class PrimaryButton(ctk.CTkButton):
    """Primary action button with custom styling."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Apply styling
        self.configure(
            corner_radius=12,
            border_width=0,
            fg_color=COLOR_SCHEME["primary"],
            hover_color=COLOR_SCHEME["primary_hover"],
            text_color=COLOR_SCHEME["bg_dark"],
            height=38,
            font=("Segoe UI", 12, "bold")
        )


class ChatMessage(ctk.CTkFrame):
    """Individual chat message component."""
    
    def __init__(self, parent, message: str, is_user: bool = False, **kwargs):
        super().__init__(
            parent, 
            fg_color=COLOR_SCHEME["bg_medium"] if is_user else "transparent", 
            corner_radius=12,
            **kwargs
        )
        
        # Message configuration
        self.message = message
        self.is_user = is_user
        
        # Create layout
        self._create_widgets()
        
    def _create_widgets(self):
        """Create the message widgets."""
        # Avatar or icon
        avatar_frame = ctk.CTkFrame(self, width=36, height=36, fg_color="transparent")
        avatar_frame.pack(side=tk.LEFT, padx=(15, 12), pady=15)
        
        avatar_label = ctk.CTkLabel(
            avatar_frame, 
            text="You" if self.is_user else "I",  # Change "P" to "I" for "Integrity"
            font=("Segoe UI", 12, "bold"),
            text_color=COLOR_SCHEME["text_primary"] if self.is_user else COLOR_SCHEME["primary"],
            width=36, 
            height=36
        )
        avatar_label.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        
        # Message content
        content_frame = ctk.CTkFrame(self, fg_color="transparent")
        content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 15), pady=15)
        
        # Message text with proper wrapping
        message_label = ctk.CTkLabel(
            content_frame,
            text=self.message,
            font=("Segoe UI", 12),
            text_color=COLOR_SCHEME["text_primary"],
            wraplength=800,  # Set a reasonable wrap length
            justify=tk.LEFT
        )
        message_label.pack(anchor=tk.W, fill=tk.BOTH, expand=True)


class ChatContainer(ctk.CTkScrollableFrame):
    """Scrollable container for chat messages."""
    
    def __init__(self, parent, **kwargs):
        super().__init__(
            parent,
            fg_color=COLOR_SCHEME["bg_dark"],
            corner_radius=0,
            **kwargs
        )
        
        self.messages = []
        
    def add_message(self, message: str, is_user: bool = False):
        """Add a new message to the chat."""
        chat_message = ChatMessage(self, message, is_user)
        chat_message.pack(fill=tk.X, padx=15, pady=(10, 0), anchor=tk.N)
        self.messages.append(chat_message)
        
        # Scroll to bottom
        self.after(100, self._scroll_to_bottom)
        
    def _scroll_to_bottom(self):
        """Scroll to the bottom of the chat."""
        canvas = self._parent_canvas
        canvas.yview_moveto(1.0)
        
    def clear(self):
        """Clear all messages from the chat."""
        for message in self.messages:
            message.destroy()
        self.messages = []


class StatusBar(ctk.CTkFrame):
    """Status bar at the bottom of the application."""
    
    def __init__(self, parent, **kwargs):
        super().__init__(
            parent, 
            height=30, 
            fg_color=COLOR_SCHEME["bg_medium"],
            **kwargs
        )
        
        # Status indicator
        self.status_indicator = PulsatingIcon(self, size=12)
        self.status_indicator.pack(side=tk.LEFT, padx=(15, 5), pady=9)
        
        # Status label
        self.status_label = ctk.CTkLabel(
            self,
            text="Ready",
            font=("Segoe UI", 11),
            text_color=COLOR_SCHEME["text_secondary"]
        )
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        # Question limit indicator
        self.limit_label = ctk.CTkLabel(
            self,
            text="100/100 questions remaining",
            font=("Segoe UI", 11),
            text_color=COLOR_SCHEME["text_secondary"]
        )
        self.limit_label.pack(side=tk.RIGHT, padx=15)
        
    def update_status(self, text: str, running: bool = False):
        """Update the status bar text and indicator."""
        self.status_label.configure(text=text)
        
        if running:
            self.status_indicator.color = COLOR_SCHEME["success"]
            self.status_indicator.start()
        else:
            self.status_indicator.color = COLOR_SCHEME["primary"]
            if text == "Ready":
                self.status_indicator.stop()
                self.status_indicator.delete("pulse")
                self.status_indicator.create_oval(
                    6 - 4, 6 - 4, 6 + 4, 6 + 4, 
                    fill=COLOR_SCHEME["primary"], 
                    outline=""
                )
            else:
                self.status_indicator.start()
    
    def update_question_limit(self, remaining: int, total: int = 100):
        """Update the question limit display."""
        self.limit_label.configure(text=f"{remaining}/{total} questions remaining")


class IntegrityUI(ctk.CTk):
    """Main Integrity Assistant UI."""
    
    def __init__(self, screen_capture, api_client, config_file=None):
        super().__init__()
        
        # Store references to core components
        self.screen_capture = screen_capture
        self.api_client = api_client
        self.config_file = config_file
        
        # Configure the window
        self.title("Integrity Assistant")
        self.geometry("900x600")
        self.minsize(600, 400)
        
        # Set initial state
        self.capture_running = False
        self.current_view = "chat"
        
        # Create UI components
        self._create_widgets()
        
        # Set up periodic status updates
        self._setup_status_updates()
        
    def _create_widgets(self):
        """Create all UI widgets."""
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)  # Header
        self.grid_rowconfigure(1, weight=1)  # Content
        self.grid_rowconfigure(2, weight=0)  # Status bar
        
        # Create header
        self._create_header()
        
        # Create content area
        self._create_content()
        
        # Create status bar
        self.status_bar = StatusBar(self)
        self.status_bar.grid(row=2, column=0, sticky="ew")
        
    def _create_header(self):
        """Create application header."""
        self.header = ctk.CTkFrame(self, fg_color=COLOR_SCHEME["bg_medium"], height=60)
        self.header.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        
        # Prevent header from resizing vertically
        self.header.grid_propagate(False)
        
        # Logo and title
        logo_frame = ctk.CTkFrame(self.header, fg_color="transparent")
        logo_frame.pack(side=tk.LEFT, padx=(20, 0))
        
        logo_label = ctk.CTkLabel(
            logo_frame,
            text="I",
            font=("Segoe UI", 24, "bold"),
            text_color=COLOR_SCHEME["primary"]
        )
        logo_label.pack(side=tk.LEFT)
        
        title_label = ctk.CTkLabel(
            logo_frame,
            text="Integrity Assistant",
            font=("Segoe UI", 18),
            text_color=COLOR_SCHEME["text_primary"]
        )
        title_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Version label
        version_label = ctk.CTkLabel(
            logo_frame,
            text="v0.1.2 Alpha",
            font=("Segoe UI", 10),
            text_color=COLOR_SCHEME["text_secondary"]
        )
        version_label.pack(side=tk.LEFT, padx=(5, 0), pady=(8, 0))
        
        # Control buttons
        control_frame = ctk.CTkFrame(self.header, fg_color="transparent")
        control_frame.pack(side=tk.RIGHT, padx=(0, 20))
        
        self.start_button = PrimaryButton(
            control_frame,
            text="Start Observing",
            width=140,
            command=self._toggle_capture
        )
        self.start_button.pack(side=tk.LEFT)
        
    def _create_content(self):
        """Create main content area."""
        # Main content container
        self.content = ctk.CTkFrame(self, fg_color=COLOR_SCHEME["bg_dark"])
        self.content.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        
        # Configure content grid
        self.content.grid_columnconfigure(0, weight=1)  # Chat area
        self.content.grid_rowconfigure(0, weight=1)     # Chat messages
        self.content.grid_rowconfigure(1, weight=0)     # Input area
        
        # Chat container
        self.chat_container = ChatContainer(self.content)
        self.chat_container.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        
        # Welcome message
        self.chat_container.add_message(
            "Hi there! I'm Integrity Assistant, your digital memory companion. I quietly observe your digital activities "
            "while you work and help you recall anything you've seen or done. "
            "Ask me things like:\n"
            "• \"What was that website I was looking at around 2PM?\"\n"
            "• \"Find that code snippet I was working on earlier\"\n"
            "• \"What were the key points from my meeting notes?\"",
            is_user=False
        )
        
        # Input area
        self.input_area = ctk.CTkFrame(
            self.content,
            fg_color=COLOR_SCHEME["bg_medium"],
            height=70
        )
        self.input_area.grid(row=1, column=0, sticky="ew", padx=0, pady=0)
        self.input_area.grid_propagate(False)
        
        # Text input
        self.input_entry = ctk.CTkEntry(
            self.input_area,
            placeholder_text="Ask me anything about your activity...",
            height=40,
            font=("Segoe UI", 13),
            fg_color=COLOR_SCHEME["bg_dark"],
            border_color=COLOR_SCHEME["border"],
            text_color=COLOR_SCHEME["text_primary"]
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(20, 10), pady=15)
        
        # Send button
        self.send_button = PrimaryButton(
            self.input_area,
            text="Ask",
            width=80,
            command=self._send_message
        )
        self.send_button.pack(side=tk.RIGHT, padx=(0, 20), pady=15)
        
        # Bind Enter key to send message
        self.input_entry.bind("<Return>", lambda event: self._send_message())
    
    def _setup_status_updates(self):
        """Set up periodic status updates."""
        def update_status():
            if self.capture_running:
                # Get stats from screen capture
                stats = self.screen_capture.get_statistics()
                
                # Update server connection status
                server_status = stats.get("server_connection", "Disconnected")
                if server_status != "Connected":
                    self.status_bar.update_status(f"Server: {server_status}", False)
                
                # Update question limit
                if self.api_client:
                    try:
                        limit_info = self.api_client.get_daily_limit()
                        self.status_bar.update_question_limit(
                            limit_info.get("remaining", 100),
                            limit_info.get("total_limit", 100)
                        )
                    except:
                        pass
            
            # Schedule next update
            self.after(10000, update_status)  # Update every 10 seconds
            
        # Start updates
        update_status()
    
    def _toggle_capture(self):
        """Toggle screen capture on/off."""
        if not self.capture_running:
            # Start capture
            try:
                self.screen_capture.start_capture()
                self.capture_running = True
                self.start_button.configure(text="Stop Observing")
                self.status_bar.update_status("Observing your activities", running=True)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to start: {str(e)}")
        else:
            # Stop capture
            try:
                self.screen_capture.stop_capture()
                self.capture_running = False
                self.start_button.configure(text="Start Observing")
                self.status_bar.update_status("Ready")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to stop: {str(e)}")
    
    def _send_message(self):
        """Send a message to the assistant."""
        # Get message text
        message = self.input_entry.get().strip()
        if not message:
            return
            
        # Clear input
        self.input_entry.delete(0, tk.END)
        
        # Add user message to chat
        self.chat_container.add_message(message, is_user=True)
        
        # Show thinking indicator
        self.status_bar.update_status("Thinking...", running=True)
        
        # Create a background thread for API call
        def get_response():
            try:
                # Export latest text content (not used by the API but for compatibility)
                text_file = self.screen_capture.export_text_to_file()
                with open(text_file, 'r', encoding='utf-8') as f:
                    text_content = f.read()
                
                # Query the API
                response = self.api_client.query_model(message, text_content)
                
                # Add response to chat
                self.after(0, lambda: self.chat_container.add_message(response))
                
                # Update status
                self.after(0, lambda: self.status_bar.update_status("Ready"))
                
                # Update question limit
                try:
                    limit_info = self.api_client.get_daily_limit()
                    self.after(0, lambda: self.status_bar.update_question_limit(
                        limit_info.get("remaining", 100),
                        limit_info.get("total_limit", 100)
                    ))
                except:
                    pass
                
            except Exception as e:
                logger.error(f"Error getting response: {e}")
                error_msg = f"Sorry, I encountered an error: {str(e)}"
                self.after(0, lambda: self.chat_container.add_message(error_msg))
                self.after(0, lambda: self.status_bar.update_status("Error occurred"))
        
        # Start background thread
        threading.Thread(target=get_response, daemon=True).start()
    
    def on_close(self):
        """Handle window close event."""
        if self.capture_running:
            if messagebox.askyesno("Exit", "Integrity Assistant is still running. Stop and exit?"):
                self.screen_capture.stop_capture()
                self.destroy()
        else:
            self.destroy()

# Function to run the UI
def run_gui(screen_capture, api_client):
    """Run the Integrity Assistant UI."""
    app = IntegrityUI(screen_capture, api_client)
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()