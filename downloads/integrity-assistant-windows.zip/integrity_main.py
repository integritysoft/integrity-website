#!/usr/bin/env python3
"""
Integrity Assistant v0.1.2 Alpha

A desktop application that captures and processes screen content,
allowing you to query your digital activities using AI.
"""

import os
import sys
import argparse
import logging
import traceback
from pathlib import Path
import platform
import subprocess
import time
import webbrowser
import json
from threading import Thread
import requests

# Import custom modules
from integrity_core import ScreenCapture
from integrity_api import IntegrityAPI
from integrity_ui import run_gui

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("integrity.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("integrity")

# Define application constants
APP_NAME = "Integrity Assistant"
APP_VERSION = "0.1.2"
APP_AUTHOR = "Integrity Team"
DEFAULT_SERVER_URL = "https://web-production-b7f3.up.railway.app"  # Removed trailing slash
DEFAULT_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".integrity")
DEFAULT_STORAGE_DIR = os.path.join(DEFAULT_CONFIG_DIR, "data")
CONFIG_FILE = os.path.join(DEFAULT_CONFIG_DIR, "config.json")

def setup_environment():
    """Set up the application environment."""
    # Create default directories if they don't exist
    os.makedirs(DEFAULT_CONFIG_DIR, exist_ok=True)
    os.makedirs(DEFAULT_STORAGE_DIR, exist_ok=True)
    os.makedirs(os.path.join(DEFAULT_STORAGE_DIR, "images"), exist_ok=True)
    
    # Check for required Python packages
    try:
        import customtkinter
        import easyocr
        import requests
    except ImportError as e:
        logger.error(f"Missing required dependency: {e}")
        print(f"Error: Missing required dependency: {e}")
        print("Please install all dependencies with: pip install -r requirements.txt")
        sys.exit(1)
    
    # Load user configuration
    user_config = load_config()
    
    return user_config

def load_config():
    """Load user configuration from file."""
    default_config = {
        "server_url": DEFAULT_SERVER_URL,
        "user_id": None,
        "user_token": None,
        "email": None,
        "username": None,
        "sampling_rate": 0.5
    }
    
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return {**default_config, **config}
    except Exception as e:
        logger.error(f"Error loading config: {e}")
    
    return default_config

def save_config(config):
    """Save user configuration to file."""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Error saving config: {e}")
        return False

def register_user():
    """Register a new user and get a token."""
    print("\n=== Create your Integrity Account ===")
    
    email = input("Enter your email address: ")
    username = input("Choose a username: ")
    
    print("\nRegistering with Integrity server...\n")
    
    api_client = IntegrityAPI(DEFAULT_SERVER_URL)
    success, message, token = api_client.register_user(email, username)
    
    if success:
        print("Registration successful! Welcome to Integrity Assistant.")
        return {
            "user_id": api_client.user_id,
            "user_token": token,
            "email": email,
            "username": username
        }
    else:
        print(f"Registration failed: {message}")
        print("Please try again or contact support.")
        return None

def check_server_connection(server_url):
    """Check if the server is reachable."""
    try:
        response = requests.get(f"{server_url}/api/health", timeout=10)  # Increased timeout
        if response.status_code == 200:
            logger.info("Server connection successful")
            return True
        else:
            logger.error(f"Server returned status code: {response.status_code}")
            return False
    except Exception as e:
        logger.error(f"Server connection failed: {str(e)}")
        return False

def main():
    """Main application entry point."""
    try:
        # Setup environment
        user_config = setup_environment()
        
        # Check if user is registered
        if not user_config.get("user_token") or not user_config.get("user_id"):
            # Check server connection
            if not check_server_connection(user_config["server_url"]):
                print("Cannot connect to Integrity server. Please check your internet connection.")
                sys.exit(1)
                
            # Register user
            user_info = register_user()
            if not user_info:
                sys.exit(1)
                
            # Update and save config
            user_config.update(user_info)
            save_config(user_config)
        
        # Initialize core components
        server_url = user_config.get("server_url")
        user_id = user_config.get("user_id")
        user_token = user_config.get("user_token")
        sampling_rate = user_config.get("sampling_rate", 0.5)
        
        screen_capture = ScreenCapture(
            storage_dir=DEFAULT_STORAGE_DIR,
            sampling_rate=sampling_rate,
            server_url=server_url,
            user_id=user_id,
            user_token=user_token
        )
        
        api_client = IntegrityAPI(
            server_url=server_url,
            user_id=user_id,
            user_token=user_token
        )
        
        # Run the GUI
        run_gui(screen_capture, api_client)
        
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        logger.error(traceback.format_exc())
        print(f"Error: {e}")
        print("See integrity.log for details")
        sys.exit(1)

if __name__ == "__main__":
    main()